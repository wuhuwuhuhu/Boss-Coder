/*
    register main container 
*/
import React, {Component} from 'react'
export default class Main extends Component {
    render(){
        return(
            <div>
                Main
            </div>
        )
    }
}