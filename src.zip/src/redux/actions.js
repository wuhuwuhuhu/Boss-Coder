/*
action creators: synchronous actions and asynchronous actions
*/